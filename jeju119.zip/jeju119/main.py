from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
import osmnx as ox
import networkx as nx
import geopandas as gpd
from shapely.geometry import Point
from scipy.spatial import cKDTree
import numpy as np
import requests
import pandas as pd
import os

app = FastAPI(title="제주 SAFE 119 API")

# ---------------------------------------------------------
# 1. 가로등 데이터 전역 로드
# ---------------------------------------------------------
CSV_FILES = ["lamp1.csv", "lamp2.csv"] 
gdf_lights = None
light_tree = None
light_coords_np = None

dfs = []
for file_path in CSV_FILES:
    if os.path.exists(file_path):
        try:
            try:
                df = pd.read_csv(file_path, encoding='cp949')
            except UnicodeDecodeError:
                df = pd.read_csv(file_path, encoding='utf-8')
            dfs.append(df)
            print(f"📄 '{file_path}' 읽기 성공 ({len(df)}개 행)")
        except Exception as e:
            print(f"⚠️ '{file_path}' 읽기 실패: {e}")

if dfs:
    try:
        combined_df = pd.concat(dfs, ignore_index=True)
        combined_df.columns = [str(c).replace(" ", "").strip() for c in combined_df.columns]
        
        lat_col = '위도'
        lon_col = '경도'
        
        df_clean = combined_df.dropna(subset=[lat_col, lon_col]).copy()
        df_clean[lat_col] = pd.to_numeric(df_clean[lat_col], errors='coerce')
        df_clean[lon_col] = pd.to_numeric(df_clean[lon_col], errors='coerce')
        df_clean = df_clean.dropna(subset=[lat_col, lon_col])

        # 제주도 위경도 범주 필터링
        df_clean = df_clean[(df_clean[lat_col] > 33.0) & (df_clean[lat_col] < 34.0) & 
                            (df_clean[lon_col] > 126.0) & (df_clean[lon_col] < 127.5)]

        # 초고속 공간 검색을 위한 KDTree 구축 (위도, 경도 좌표)
        light_coords_np = df_clean[[lat_col, lon_col]].to_numpy()
        light_tree = cKDTree(light_coords_np)
        
        geometry = [Point(xy) for xy in zip(df_clean[lon_col], df_clean[lat_col])]
        gdf_lights = gpd.GeoDataFrame(df_clean, geometry=geometry, crs="EPSG:4326")
            
        print(f"✅ 가로등 데이터 최종 정제 및 KDTree 구축 완료: {len(df_clean)}개 좌표 준비\n")
    except Exception as e:
        print(f"⚠️ 가로등 데이터 가공 실패: {e}")

# ---------------------------------------------------------
# 2. 위치 검색 함수
# ---------------------------------------------------------
KAKAO_API_KEY = "e1f31eaff8008955af89c9917c75067e"

def get_location(query: str):
    try:
        headers = {"Authorization": f"KakaoAK {KAKAO_API_KEY}", "Origin": "http://localhost"}
        url_address = "https://dapi.kakao.com/v2/local/search/address.json"
        res_addr = requests.get(url_address, headers=headers, params={"query": query}, timeout=3).json()
        if 'documents' in res_addr and len(res_addr['documents']) > 0:
            doc = res_addr['documents'][0]
            return float(doc['y']), float(doc['x']), doc.get('address_name', query)

        url_keyword = "https://dapi.kakao.com/v2/local/search/keyword.json"
        res_kw = requests.get(url_keyword, headers=headers, params={"query": query}, timeout=3).json()
        if 'documents' in res_kw and len(res_kw['documents']) > 0:
            doc = res_kw['documents'][0]
            return float(doc['y']), float(doc['x']), doc['place_name']
    except Exception:
        pass

    try:
        search_query = f"{query}, 제주도" if "제주" not in query else query
        url = f"https://nominatim.openstreetmap.org/search?format=json&q={search_query}"
        headers = {"User-Agent": "JejuSafe119/1.0"}
        res = requests.get(url, headers=headers, timeout=5).json()
        if res and len(res) > 0:
            return float(res[0]['lat']), float(res[0]['lon']), query
    except Exception:
        pass

    raise ValueError(f"'{query}' 위치를 찾을 수 없습니다.")

# ---------------------------------------------------------
# 3. 경로 계산 엔드포인트
# ---------------------------------------------------------
@app.get("/", response_class=HTMLResponse)
def read_root():
    if os.path.exists("index.html"):
        with open("index.html", "r", encoding="utf-8") as f:
            return f.read()
    return "<h1>index.html 파일이 없습니다.</h1>"

@app.get("/api/navigate")
def navigate(start: str, end: str):
    try:
        start_lat, start_lng, start_name = get_location(start)
        end_lat, end_lng, end_name = get_location(end)
        
        dist = ox.distance.great_circle(start_lat, start_lng, end_lat, end_lng)
        if dist > 10000:
            return {"success": False, "error": f"직선거리({dist/1000:.1f}km)가 도보 범위를 초과했습니다."}
            
        center_lat, center_lon = (start_lat + end_lat) / 2, (start_lng + end_lng) / 2
        G = ox.graph_from_point((center_lat, center_lon), dist=max(dist * 0.85, 2000), network_type='walk')
        
        # 도로 구간별 가로등 개수 산출 (KDTree 근접 30m 검색 방식)
        # 위경도 약 0.0003도 = 약 30미터
        SEARCH_RADIUS_DEGREE = 0.0003
        
        edge_light_counts = {}
        total_matched_lights = 0
        
        for u, v, key, data in G.edges(keys=True, data=True):
            node_u = G.nodes[u]
            node_v = G.nodes[v]
            
            # 도로 세그먼트의 중점 좌표 계산
            mid_lat = (node_u['y'] + node_v['y']) / 2
            mid_lon = (node_u['x'] + node_v['x']) / 2
            
            if light_tree is not None:
                # 도로 중점 기준 30m 반경 안의 가로등 수 카운트
                indices = light_tree.query_ball_point([mid_lat, mid_lon], r=SEARCH_RADIUS_DEGREE)
                count = len(indices)
            else:
                count = 0
                
            edge_light_counts[(u, v, key)] = count
            total_matched_lights += count

        print(f"💡 [KDTree 매칭 성공!] 탐색 영역 도로상에 매칭된 가로등 총 {total_matched_lights}개 발견")

        # 가로등 기반 가중치 재산정 (가로등 1개당 가중치 경감)
        safety_factor = 15
        for u, v, key, data in G.edges(keys=True, data=True):
            count = edge_light_counts.get((u, v, key), 0)
            data['light_count'] = count
            length = data.get('length', 1)
            # 안전 경로용 가중치 계산 공식
            data['safe_weight'] = length / (1 + (count * safety_factor))

        start_node = ox.distance.nearest_nodes(G, X=start_lng, Y=start_lat)
        end_node = ox.distance.nearest_nodes(G, X=end_lng, Y=end_lat)

        fastest_path = nx.shortest_path(G, start_node, end_node, weight='length')
        safest_path = nx.shortest_path(G, start_node, end_node, weight='safe_weight')

        def extract_path_info(path):
            coords = [[G.nodes[n]['y'], G.nodes[n]['x']] for n in path]
            total_dist = 0
            total_lights = 0
            for i in range(len(path) - 1):
                u, v = path[i], path[i+1]
                # 다중 그래프 데이터 파싱
                edge_data = list(G[u][v].values())[0]
                total_dist += edge_data.get('length', 0)
                total_lights += edge_data.get('light_count', 0)
            return coords, round(total_dist), int(total_lights)

        fast_coords, fast_dist, fast_lights = extract_path_info(fastest_path)
        safe_coords, safe_dist, safe_lights = extract_path_info(safest_path)

        return {
            "success": True,
            "start": {"name": start_name, "lat": start_lat, "lng": start_lng},
            "end": {"name": end_name, "lat": end_lat, "lng": end_lng},
            "fastest_path": {
                "coords": fast_coords,
                "distance_m": fast_dist,
                "time_min": int(fast_dist / 66),
                "lights": fast_lights
            },
            "safest_path": {
                "coords": safe_coords,
                "distance_m": safe_dist,
                "time_min": int(safe_dist / 66),
                "lights": safe_lights
            }
        }
    except Exception as e:
        return {"success": False, "error": f"경로 계산 오류: {str(e)}"}